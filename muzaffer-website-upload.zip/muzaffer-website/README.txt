Für Netlify: Lege die echte Bilddatei als muzaffer.webp in diesen Ordner. Passe in index.html WhatsApp-Nummer, Telefonnummer/Adresse und PayPal-Benutzername an.
